package com.gb.parkinglot.model.parking;

public enum ParkingSpotType {
    ABLED,
    CAR,
    LARGE,
    MOTORBIKE,
    ELECTRIC,
    EBIKE
}
