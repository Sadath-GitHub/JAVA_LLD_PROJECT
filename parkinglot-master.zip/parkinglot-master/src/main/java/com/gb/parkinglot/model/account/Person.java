package com.gb.parkinglot.model.account;

public class Person {
}
