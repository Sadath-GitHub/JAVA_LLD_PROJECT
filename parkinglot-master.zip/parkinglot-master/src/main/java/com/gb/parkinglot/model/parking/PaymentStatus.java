package com.gb.parkinglot.model.parking;

public enum PaymentStatus {
    SUCCESS,
    FAILED
}
