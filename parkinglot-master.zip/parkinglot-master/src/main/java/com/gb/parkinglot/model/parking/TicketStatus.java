package com.gb.parkinglot.model.parking;

public enum TicketStatus {
    ACTIVE,
    LOST
}
