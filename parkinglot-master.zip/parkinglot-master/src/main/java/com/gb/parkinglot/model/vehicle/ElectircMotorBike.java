package com.gb.parkinglot.model.vehicle;

public class ElectircMotorBike extends Vehicle {
    public ElectircMotorBike(String licenseNumber) {
        super(licenseNumber, VehicleType.EBIKE);
    }
}
